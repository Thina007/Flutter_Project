import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sample/models/brew.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:sample/models/user.dart';

import 'package:sample/services/database.dart';
import 'package:sample/services/storage.dart';

class BrewTile extends StatefulWidget {
  final Brew? brew;
  BrewTile({this.brew});

  @override
  _BrewTileState createState() => _BrewTileState();
}

class _BrewTileState extends State<BrewTile> {
  PickedFile? imageFile;
  String? msg;

  putFile(ImageSource source, String? uid) async {
    final file = await ImagePicker.platform.pickImage(source: source);
    imageFile = file;
    msg = await StorageService().uploadImage(imageFile!, uid!);
    setState(() {
      print('Message: ' + msg!);
    });
  }

  @override
  Widget build(BuildContext context) {
    //print('Thinagaran unaku matum yan da ipdi nadakuthu !!!');
    final user = Provider.of<MyUser?>(context);
    //print(widget.brew!.strength);
    Widget bottomsheet() {
      return Container(
        width: MediaQuery.of(context).size.width,
        height: 120,
        margin: EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 20,
        ),
        child: Column(
          children: [
            Text(
              'Choose Profile photo',
              style: TextStyle(fontSize: 20.0),
            ),
            SizedBox(
              height: 20.0,
            ),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              FlatButton.icon(
                onPressed: () async {
                  await putFile(ImageSource.camera, user!.uid);
                  Navigator.pop(context);
                },
                icon: Icon(Icons.camera),
                label: Text('Camera'),
              ),
              FlatButton.icon(
                onPressed: () async {
                  await putFile(ImageSource.gallery, user!.uid);
                  Navigator.pop(context);
                },
                icon: Icon(Icons.image),
                label: Text('Gallery'),
              ),
            ]),
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Container(
        height: null,
        width: 100,
        color: Colors.grey[300],
        padding: EdgeInsets.fromLTRB(20, 6, 20.0, 0.0),
        child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: CircleAvatar(
                  // child: IconButton(
                  //     onPressed: () {
                  //       showBottomSheet(
                  //           context: context,
                  //           builder: ((builder) => bottomsheet()));
                  //     },
                  //     alignment: Alignment.bottomRight,
                  //     icon: Icon(Icons.camera_alt),
                  //     iconSize: 15),
                  radius: 30,
                  backgroundImage: widget.brew!.strength == ''
                      ? AssetImage('assets/profile.png')
                      : NetworkImage((widget.brew!.strength)!) as ImageProvider,
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    '   ' + (widget.brew!.name)!,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                        fontSize: 17),
                  ),
                  Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.brew!.sugars.toString(),
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.blue,
                              fontSize: 15),
                        ),
                      ]),
                ],
              ),
            ]),
      ),
    );
  }
}
