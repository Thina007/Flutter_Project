import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sample/models/brew.dart';
import 'package:sample/models/user.dart';
import 'package:sample/screens/home/brew_tile.dart';
import 'package:sample/services/auth.dart';

class BrewList extends StatefulWidget {
  @override
  _BrewListState createState() => _BrewListState();
}

class _BrewListState extends State<BrewList> {
  @override
  Widget build(BuildContext context) {
    final brews = Provider.of<List<Brew>?>(context) ?? [];

    //print(brews.length);
    return ListView.builder(
        itemCount: brews.length,
        itemBuilder: (context, index) {
          return BrewTile(brew: brews[index]);
        });
  }
}
