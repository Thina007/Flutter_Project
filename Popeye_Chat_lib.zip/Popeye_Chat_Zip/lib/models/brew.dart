class Brew {
  String? name;
  String? sugars;
  String? strength;
  String? email;
  String? password;

  Brew({this.name, this.sugars, this.strength, this.email, this.password});
}
