import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sample/models/user.dart';
import 'package:sample/screens/wrapper.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:sample/services/auth.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(Myapp());
}

class Myapp extends StatelessWidget {
  const Myapp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamProvider<MyUser?>.value(
      catchError: (User, MyUser) => null,
      value: AuthService().user,
      initialData: null,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Wrapper(),
      ),
    );
  }
}

//  keytool -genkey -v -keystore c:\Users\thina\upload-keystore.jks -storetype JKS -keyalg RSA -keysize 2048 -validity 10000 -alias upload
//c:\Users\thina\upload-keystore.jks
//keytool -list -v -keystore "C:\Users\thina\.android\debug.keystore" -alias androiddebugkey -storepass android -keypass android
//Serial number: 1
// Valid from: Sat Jul 31 21:04:36 IST 2021 until: Mon Jul 24 21:04:36 IST 2051
// Certificate fingerprints:
//          SHA1: 84:28:D3:86:B6:03:72:EE:1F:EA:5B:8E:8C:6E:77:B4:7E:E0:73:C6
//          SHA256: 96:6B:0B:77:91:42:A8:F5:40:7F:F1:C6:AC:BD:B1:D9:06:11:9F:F5:4E:08:50:58:B8:34:B3:F0:33:16:D8:E7
// Signature algorithm name: SHA1withRSA (weak)
// Subject Public Key Algorithm: 2048-bit RSA key
// Version: 1