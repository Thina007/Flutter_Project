import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file/file.dart';
import 'package:sample/models/brew.dart';
import 'package:sample/models/user.dart';
import 'package:image_picker/image_picker.dart';

class DatabaseService {
  final String? uid;
  DatabaseService({this.uid});

  //Collection reference
  final CollectionReference brewCollection =
      FirebaseFirestore.instance.collection('Popeye');

  Future updateUserData(String sugars, String name, String strength,
      String email, String password) async {
    return await brewCollection.doc(uid).set({
      'sugars': sugars,
      'name': name,
      'strength': strength,
      'email': email,
    });
  }

  Future updateProfile(field, value) async {
    try {
      print('uid:' + uid!);
      if (value != '') {
        await brewCollection.doc(uid).update({
          'strength': value,
        });
        return 'Profile Updated';
      } else {
        throw FirebaseException(
          plugin: 'Field-Unchanged',
          message: 'Field might be empty or unchanged',
        );
      }
    } on FirebaseException catch (e) {
      print(e.message);
      return e.message;
    }
  }

  updatemessage(String message) async {
    DocumentSnapshot snapshot = await brewCollection.doc(uid).get();
    brewCollection.doc(uid).update({
      'sugars': snapshot['sugars'] == '  >>>  **_message deleted_**'
          ? '  >>> ' + message
          : snapshot['sugars'] + '\n' + '  >>> ' + message
    });
  }

  updateName(String name) async {
    brewCollection.doc(uid).update({'name': name});
  }

  deletemessage() async {
    brewCollection.doc(uid).update({'sugars': '  >>>  **_message deleted_**'});
  }

// brew list from snapshot.
  List<Brew> _brewListFromSnapshot(QuerySnapshot snapshot) {
    return snapshot.docs.map((doc) {
      return Brew(
        name: doc.get('name') ?? "",
        strength: doc.get('strength') ?? 0,
        sugars: doc.get('sugars') ?? '0',
        //email: doc.get('email') ?? '',
        // password: doc.get('password') ?? '',
      );
    }).toList();
  }

  // Userdata form snapchat:
  UserData _userDataFromSnapshot(DocumentSnapshot snapshot) {
    return UserData(
      uid: uid,
      name: snapshot['name'],
      sugar: snapshot['sugars'],
      strength: snapshot['strength'],
      email: snapshot['email'],
    );
  }

//get brews stream.
  Stream<List<Brew>> get brews {
    return brewCollection.snapshots().map(_brewListFromSnapshot);
  }

//get user doc stream
  Stream<UserData> get userData {
    return brewCollection.doc(uid).snapshots().map(_userDataFromSnapshot);
  }
}
