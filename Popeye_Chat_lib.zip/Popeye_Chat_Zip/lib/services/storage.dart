import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sample/services/database.dart';

class StorageService {
  final Reference store = FirebaseStorage.instance.ref();

  uploadImage(PickedFile file, String fileName) async {
    if (file != null) {
      var task =
          store.child('/profile-image/$fileName').putFile(File(file.path));
      var taskSnap = await task;
      String url = await taskSnap.ref.getDownloadURL();
      print(url);
      return await DatabaseService(uid: fileName)
          .updateProfile('profilePic', url);
    }
  }
}
