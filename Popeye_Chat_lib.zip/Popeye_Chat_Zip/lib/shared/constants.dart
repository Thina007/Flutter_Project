import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

const textInputDecoration = InputDecoration(
    hintStyle: TextStyle(color: Colors.red),
    fillColor: Colors.white,
    filled: true,
    enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(
      color: Colors.white,
      width: 2,
    )),
    focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(
      color: Colors.pink,
      width: 2,
    )));

const textInputDecorationn = InputDecoration(
    labelText: 'Chat here',
    hintStyle: TextStyle(color: Colors.black),
    fillColor: Colors.white,
    filled: true,
    enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(
      color: Colors.black,
      width: 1,
    )),
    focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(
      color: Colors.black,
      width: 1,
    )));
const textInputDecorationnn = InputDecoration(
    contentPadding: EdgeInsets.all(0),
    hintStyle: TextStyle(color: Colors.black),
    fillColor: Colors.white,
    filled: true,
    enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(
      color: Colors.black,
      width: 1,
    )),
    focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(
      color: Colors.black,
      width: 1,
    )));
