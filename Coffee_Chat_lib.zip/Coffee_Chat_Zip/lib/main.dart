import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sample/models/user.dart';
import 'package:sample/screens/wrapper.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:sample/services/auth.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(Myapp());
}

class Myapp extends StatelessWidget {
  const Myapp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamProvider<MyUser?>.value(
      catchError: (User, MyUser) => null,
      value: AuthService().user,
      initialData: null,
      child: MaterialApp(
        home: Wrapper(),
      ),
    );
  }
}
