import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sample/models/user.dart';
import 'package:sample/screens/authenticate/authenticate.dart';
import 'package:sample/screens/home/home.dart';

class Wrapper extends StatelessWidget {
  const Wrapper({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<MyUser?>(context);
    //print("User id :" + user!.uid.toString());

    if (user == null) {
      return Authenticate();
    } else {
      return Home();
    }
  }
}
