import 'package:flutter/material.dart';
import 'package:sample/models/user.dart';
import 'package:sample/services/database.dart';
import 'package:sample/shared/constants.dart';
import 'package:provider/provider.dart';
import 'package:sample/shared/loading.dart';

class SettingForm extends StatefulWidget {
  const SettingForm({Key? key}) : super(key: key);

  @override
  _SettingFormState createState() => _SettingFormState();
}

class _SettingFormState extends State<SettingForm> {
  final _keyform = GlobalKey<FormState>();
  final List<String> sugar = ['0', '1', '2', '3', '4', '5'];

  //form value
  String? _currentName;
  String? _currentSugar;
  int? _currentStrength = 100;
  bool strFlag = true;

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<MyUser?>(context);
    return StreamBuilder<UserData>(
        stream: DatabaseService(uid: (user!.uid)).userData,
        builder: (context, snapshot) {
          if (snapshot.data != null) {
            UserData? userData = snapshot.data;
            return Form(
                key: _keyform,
                child: Column(
                  children: [
                    Text(
                      'Update Your Brew Setting',
                      style: TextStyle(fontSize: 18.0),
                    ),
                    SizedBox(height: 15),
                    TextFormField(
                      decoration: textInputDecoration.copyWith(
                        labelText: 'Name',
                        fillColor: Colors.grey[300],
                      ),
                      enabled: false,
                      initialValue: userData!.name,
                      validator: (val) =>
                          val!.isEmpty ? 'Enter an Name Please !!!' : null,
                      onChanged: (val) {
                        setState(() {
                          _currentName = val;
                        });
                      },
                    ),
                    SizedBox(
                      height: 15,
                    ),

                    //dropdown
                    DropdownButtonFormField(
                      value: userData.sugar!.isEmpty
                          ? _currentSugar
                          : userData.sugar,
                      items: sugar.map((sugar) {
                        return DropdownMenuItem(
                          value: sugar,
                          child: Text('$sugar Sugars'),
                        );
                      }).toList(),
                      onChanged: (val) =>
                          setState(() => _currentSugar = val.toString()),
                    ),
                    SizedBox(height: 23.0),

                    //Slider
                    Slider(
                      // value:
                      //     (_currentStrength ?? userData.strength)!.toDouble(),
                      value: (userData.strength != 0
                              ? _currentStrength
                              : userData.strength)!
                          .toDouble(),
                      // value: (userData.strength)!.toDouble(),
                      activeColor: Colors.brown[
                          (strFlag ? userData.strength : _currentStrength)!],
                      inactiveColor: Colors.brown[
                          (strFlag ? userData.strength : _currentStrength)!],

                      min: 100.0,
                      max: 900.0,
                      divisions: 8,
                      onChanged: (val) =>
                          setState(() => _currentStrength = val.round()),
                      // onChanged: (val) =>
                      //     setState(() => _currentStrength = val.round()),
                    ),
                    SizedBox(
                      height: 15.0,
                    ),
                    RaisedButton(
                      onPressed: () async {
                        if (_keyform.currentState!.validate()) {
                          await DatabaseService(uid: user.uid).updateUserData(
                            _currentSugar ?? snapshot.data!.sugar!,
                            _currentName ?? snapshot.data!.name!,
                            _currentStrength ?? snapshot.data!.strength!,
                          );
                          Navigator.pop(context);
                        }
                      },
                      color: Colors.pink,
                      child: Text(
                        'Update',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 18.0,
                        ),
                      ),
                    ),
                  ],
                ));
          } else {
            return Loading();
          }
        });
  }
}
